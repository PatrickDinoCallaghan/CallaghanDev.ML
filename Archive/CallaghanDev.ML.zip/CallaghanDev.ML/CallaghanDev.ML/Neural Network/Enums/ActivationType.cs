﻿namespace CallaghanDev.ML
{
    public enum ActivationType
    {
        None,
        Sigmoid,
        Tanh,
        Relu,
        Leakyrelu,
    }
}
