﻿namespace CallaghanDev.ML
{
    public enum AccelerationType
    {
        CPU,
        GPU,
        CUDA
    }

}
