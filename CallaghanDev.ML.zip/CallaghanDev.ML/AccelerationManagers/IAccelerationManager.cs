using CallaghanDev.ML.AccelerationManagers.GPU;
using CallaghanDev.ML.Enums;
using CallaghanDev.ML.Transformers.TACAMT;
using ILGPU.Runtime;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CallaghanDev.ML.AccelerationManagers
{
    public interface IAccelerationManager
    {
        #region Shared Tensor primitives
        /// <summary>
        /// Matrix-matrix multiplication: C = A * B
        /// Critical for transformer operations
        /// </summary>
        float[,] MatrixMultiply(float[,] A, float[,] B);

        /// <summary>
        /// Matrix-matrix multiplication with transpose: C = A * B^T
        /// Essential for attention: Q * K^T
        /// </summary>
        float[,] MatrixMultiplyTranspose(float[,] A, float[,] B);


        /// <summary>
        /// Element-wise matrix scaling
        /// </summary>
        float[,] MatrixScale(float[,] matrix, float scalar);

        /// <summary>
        /// Element-wise matrix addition
        /// </summary>
        float[,] MatrixAdd(float[,] A, float[,] B);

        float[,] MatrixAddBias(float[,] matrix, float[] bias);

        /// <summary>
        /// Batch matrix-vector dot products: computes weights * inputRows[i] for each row.
        /// Replaces row-by-row CalculateDotProduct loops in MatMulWithBias/ProjectToVocab.
        /// </summary>
        float[,] BatchDotProduct(float[,] weights, float[,] inputMatrix);

        float[,] BatchDotProduct(float[,] weights, float[,] inputMatrix, int rowStart, int rowCount);

        /// <summary>
        /// Extract rows [startRow, endRow) from a matrix.
        /// </summary>
        float[,] SliceRows(float[,] matrix, int startRow, int endRow);


        /// <summary>
        /// Copy one row from a matrix into a new vector.
        /// </summary>
        float[] ExtractRow(float[,] matrix, int rowIndex, int cols);


        /// <summary>
        /// Copy a vector into one row of a matrix.
        /// </summary>
        void SetRow(float[,] matrix, int rowIndex, float[] values, int cols);

        /// <summary>
        /// Zero out a matrix (can use SIMD/parallel clearing).
        /// </summary>
        void ZeroMatrix(float[,] matrix);


        /// <summary>
        /// Zero out a vector.
        /// </summary>
        void ZeroVector(float[] vector);

        /// <summary>
        /// In-place element-wise: target[i,j] += source[i,j]
        /// </summary>
        void MatrixAddInPlace(float[,] target, float[,] addend);


        /// <summary>
        /// Element-wise vector accumulation: target[j] += source[j]
        /// </summary>
        void VectorAccumulate(float[] target, float[] source);

        #endregion

        #region Neural network
        float[] CalculateDotProduct(float[,] matrix, float[] vector);
        (float[] activation, float[] derivative) ActivateLayer(float[] dot, float[] bias, ActivationType activationType);
        float[] CalculateOutputGradients(float[] cost, float[] derivative);
        float[] CalculateHiddenGradients(float[,] weights, float[] nextDeltas, float[] derivative);
        float[,] UpdateWeights(float[,] weights, float[] deltas, float[] prevActivations, float learningRate, float lambda);
        float[] UpdateBias(float[] bias, float[] deltas, float learningRate);

        #endregion

        #region Transformer core

        /// <summary>
        /// Row-wise softmax with optional masking for attention
        /// </summary>
        float[,] Softmax(float[,] matrix, bool[,] mask = null);


        /// <summary>
        /// Layer normalization for transformer blocks
        /// </summary>
        float[,] LayerNorm(float[,] input, float[] gamma, float[] beta, float epsilon = 1e-5f);

        /// <summary>
        /// Layer norm forward with cache outputs, parallelized across rows.
        /// </summary>
        (float[,] output, float[] means, float[] variances, float[,] normalized) LayerNormForward(float[,] input, float[] gamma, float[] beta, float epsilon = 1e-5f);

        /// <summary>
        /// Layer norm backward, parallelized across rows.
        /// </summary>
        (float[,] dInput, float[] dGamma, float[] dBeta) LayerNormBackward(float[,] dOut, float[,] normalized, float[] gamma, float[,] input, float[] mean, float[] variance, float epsilon = 1e-5f);


        /// <summary>
        /// Create a lower-triangular causal mask: mask[i,j] = (j &lt;= i).
        /// </summary>
        bool[,] CreateCausalMask(int seqLen);

        /// <summary>
        /// Parallel per-head attention forward: computes all heads concurrently.
        /// Returns concatenated [seqLen, embeddingDim] output.
        /// </summary>
        float[,] MultiHeadAttentionForward(float[,] Q, float[,] K, float[,] V, int numHeads, float scale, bool[,] mask = null);


        /// <summary>
        /// Parallel per-head attention backward: computes dQ, dK, dV across all heads concurrently.
        /// </summary>
        (float[,] dQ, float[,] dK, float[,] dV) MultiHeadAttentionBackward(float[,] Q, float[,] K, float[,] V, float[,] dConcatenated, int numHeads, float scale, bool useDecoderMask = false);

        (float[,] dQ, float[,] dK, float[,] dV) MultiHeadAttentionBackward(float[,] Q, float[,] K, float[,] V, float[,] dConcatenated, int numHeads, float scale, bool[,] mask);

        float[,] FFNForwardBatch(float[,] input, int seqLen, int outputDim, Func<float[], float[]> forwardPassFn);

        float[,] ScaledDotProductAttention(float[,] q, float[,] k, float[,] v, int numHeads, bool[,] mask = null, bool causal = false);

        (float[,] Q, float[,] K, float[,] V) ProjectQKV(float[,] input, float[,] WQ, float[] biasQ, float[,] WK, float[] biasK, float[,] WV, float[] biasV);

        float[,] BackpropQKV(float[,] input, float[,] dQ, float[,] dK, float[,] dV, float[,] WQ, float[,] WK, float[,] WV, float[,] WQGrad, float[] biasQGrad, float[,] WKGrad, float[] biasKGrad, float[,] WVGrad, float[] biasVGrad);


        #endregion

        #region Transformer training

        /// <summary>
        /// Backprop through linear projection: accumulates weight/bias grads and input gradient.
        /// Parallelizes the triple nested loop in BackpropLinearProjection.
        /// </summary>
        void BackpropLinearProjection(float[,] input, float[,] dOutput, float[,] weights, float[,] weightGrad, float[] biasGrad, float[,] dInput);

        float[,] BackpropOutputProjection(float[,] dLogits, float[,] input, float[,] weights, float[,] weightGrad, float[] biasGrad, int seqLen, int outputDim, int embeddingDim);

        /// <summary>
        /// Backprop through input projection (continuous inputs).
        /// Accumulates into weightGrad and biasGrad.
        /// </summary>
        void BackpropInputProjection(float[,] dX, float[,] continuousInput, float[,] weightGrad, float[] biasGrad, int seqLen, int embeddingDim, int inputFeatureDim);

        /// <summary>
        /// Backprop through input projection using a row slice of continuousInput without requiring
        /// the caller to allocate a sliced matrix. The active input row for dX[i,*] is
        /// continuousInput[inputRowStart + i,*].
        /// </summary>
        void BackpropInputProjection(float[,] dX, float[,] continuousInput, int inputRowStart, float[,] weightGrad, float[] biasGrad, int seqLen, int embeddingDim, int inputFeatureDim);


        /// <summary>
        /// Accumulates embedding gradients: embeddingGrad[tokenIds[i], j] += dX[i, j]
        /// </summary>
        void AccumulateTokenEmbeddingGrad(float[,] embeddingGrad, float[,] dX, int[] tokenIds, int seqLen, int embeddingDim);

        (float loss, float[,] dLogits) CrossEntropyLossAndGradient(float[,] logits, int[] targets, int effectiveLen);


        (float loss, float[,] dOutput) MSELossAndGradient(float[,] predictions, float[,] targets, int effectiveLen);



        /// <summary>
        /// Computes squared Frobenius norm of a matrix (for gradient clipping).
        /// </summary>
        float MatrixSquaredNorm(float[,] matrix);



        /// <summary>
        /// Squared L2 norm of a vector (for gradient clipping).
        /// </summary>
        float VectorSquaredNorm(float[] vector);



        /// <summary>
        /// In-place scale all elements of a matrix.
        /// </summary>
        void MatrixScaleInPlace(float[,] matrix, float scale);

        /// <summary>
        /// In-place scale all elements of a vector.
        /// </summary>
        void VectorScaleInPlace(float[] vector, float scale);


        /// <summary>
        /// SGD weight update: weights -= lr * gradients, parallelized.
        /// </summary>
        void MatrixUpdate(float[,] weights, float[,] gradients, float learningRate);

        void VectorUpdate(float[] weights, float[] gradients, float learningRate);
        #endregion

        #region Transformer specific - Multimodal/TACAMT/MMTAC

        void ApplyContextTypeEmbedding(float[,] contextHidden, float[,] typeEmbedding, int[] typeIndices);

        float[,] ComputeTimeDiffMatrix(int priceSeqLen, float[] keyArrivalTimes);

        float[] ComputeMemoryAttentionScores(float[,] priceHidden, int lastPos, float[,] contextHidden, int totalCtx, float scale);

        float[,] ProjectOutputBatch(float[,] hidden, float[,] outputProjection, float[] outputBias, int seqLen, int outputDim);

        (float[,,] decayBias, ContentAwareDecayCache cache) ContentAwareDecayForward(float[,] queryEmbeddings, float[,] keyEmbeddings, float[,] timeDiffs, float[] keyTimesFromRef, CallaghanDev.ML.Transformers.TACAMT.ContentAwareDecayNetwork network, bool isTraining = false, Random dropoutRng = null);

        float[,] ContentAwareCrossAttentionForward(float[,] Q, float[,] K, float[,] V, int numHeads, float scale, float[,,] decayBias, out float[][,] attentionWeights, out float[][,] scoresPreSoftmax);

        float[,] ContentAwareCrossAttentionWithCache(float[,] Q, float[,] K, float[,] V, float[,] timeDiffs, float[] keyTimesFromRef, float[,] queryEmbeddings, float[,] keyEmbeddings, TacamtBlock block, BlockCache bc, int PriceEmbeddingDim, int PriceNumHeads, bool enableDecayBias = true, bool isTraining = false, Random dropoutRng = null);

        void Matrix3DScaleInPlace(float[,,] matrix, float scale);

        public float MatrixSquaredNorm3D(float[,,] matrix);

        #region MMTAC

        float[] ProjectGlobalFeatures(float[] globalFeatures, float[,] projection, float[] bias);

        float[,] EmbedTokenIds(int[] tokenIds, float[,] embedding, int embeddingDim);

        float[] MeanPoolRows(float[,] matrix);

        (float[,] contextHidden, float[] contextTimes, int numGlobal, int numNews) BuildMmtacContext(float[,] newsHidden, float[] newsTimes, float[] globalToken, float[,] contextTypeEmbedding);

        (float[,] regression, float[,] range, float[,] quality, float[,] direction, float[,] midDirection, float[,] confidence, float[,] regressionLogits, float[] rangeLogits, float[] qualityLogits) ProjectMmtacOutputHeads(float[,] hidden, float[,] regressionProjection, float[] regressionBias, float[,] rangeProjection, float[] rangeBias, float[,] qualityProjection, float[] qualityBias, float[,] directionProjection, float[] directionBias, float[,] midDirectionProjection, float[] midDirectionBias, float[,] confidenceProjection, float[] confidenceBias, bool useConfidenceHead);

        float[] SoftmaxVector(float[] scores);

        (float[,] dQ, float[,] dK, float[,] dV, float[,,] dDecayBias) BackpropTimeDecayedAttention(float[,] q, float[,] k, float[,] v, float[,] dOutput, float[][,] attentionWeights, float[,] timeDiffs, int embeddingDim, int numHeads);

        #endregion

        #endregion

        #region Tokenizer Acceleration

        string[] PreTokenize(string text);

        Dictionary<string, int> GetWordFrequencies(string[] texts, bool lowerCase);

        HashSet<string> BuildCharacterVocabulary(Dictionary<string, int> wordFreqs);

        List<string> ApplyMerge(List<string> word, string left, string right);

        List<int> EncodeWord(string word, Dictionary<(string, string), int> mergePriority, Dictionary<string, int> vocabToId, int unkTokenId);

        Dictionary<(string left, string right), int> CountPairFrequencies(Dictionary<List<string>, int> words);

        ((string left, string right) pair, int frequency) SelectBestPair(Dictionary<(string left, string right), int> pairCounts, int minFrequency);

        Dictionary<List<string>, int> ApplyMergeToVocabulary(Dictionary<List<string>, int> words, string left, string right);

        string DecodeTokens(int[] tokenIds, Dictionary<int, string> idToVocab, string unkToken, bool skipSpecialTokens);

        int[] PadOrTruncate(int[] tokenIds, int maxLength, bool addSpecialTokens, int padTokenId, int endTokenId);

        #endregion

        #region Rotary Position Embeddings

        void ApplyRotaryPositionEmbeddingHeadInPlace(float[,] matrix, int startCol, int headDim, float baseTheta, bool inverse);
        void ApplyRotaryPositionEmbeddingInPlace(float[,] matrix, int numHeads, float baseTheta, bool inverse);

        #endregion

        void SigmoidInPlace(float[,] matrix);
        void Dispose();

        void ZeroMatrixColumns(float[,] matrix, int columnCount);

        (float[,] K, float[,] V) ProjectKV(float[,] input, float[,] WK, float[] biasK, float[,] WV, float[] biasV);

        float[,] BackpropKV(float[,] input, float[,] dK, float[,] dV, float[,] WK, float[,] WV, float[,] WKGrad, float[] biasKGrad, float[,] WVGrad, float[] biasVGrad);

        void Matrix3DAddInPlace(float[,,] target, float[,,] addend);

        void Matrix3DUpdate(float[,,] weights, float[,,] gradients, float learningRate);

        void VectorUpdateClamped(float[] weights, float[] gradients, float learningRate, float minValue, float maxValue);

        (float[,] contextHidden, float[] contextTimes, int numGlobal, int numNews, int numPrice) BuildMmtacContextWithPrice(float[,] newsHidden, float[] newsTimes, float[] globalToken, float[,] priceContextHidden, float[] priceContextTimes, float[,] contextTypeEmbedding);

        (float loss, float[,] dHidden) BackpropMmtacOutputHeads(
            float[,] regression, float[,] range, float[,] quality, float[,] direction, float[,] midDirection, float[,] confidence,
            float[,] targetRegression, float[,] targetRange, float[,] targetQuality, float[,] targetDirection, float[,] targetMidDirection,
            float[] previousClose, float[] confidenceTargets,
            float[,] hidden, float[,] regressionLogits, float[] rangeLogits,
            float[,] regressionProjection, float[,] rangeProjection, float[,] qualityProjection, float[,] directionProjection, float[,] midDirectionProjection, float[,] confidenceProjection,
            float[,] regressionProjectionGrad, float[] regressionBiasGrad,
            float[,] rangeProjectionGrad, float[] rangeBiasGrad,
            float[,] qualityProjectionGrad, float[] qualityBiasGrad,
            float[,] directionProjectionGrad, float[] directionBiasGrad,
            float[,] midDirectionProjectionGrad, float[] midDirectionBiasGrad,
            float[,] confidenceProjectionGrad, float[] confidenceBiasGrad,
            float rangeLossWeight, float qualityLossWeight, float directionLossWeight, float midDirectionLossWeight,
            float closeDirectionConsistencyWeight, float closeDirectionConsistencyMargin, float confidenceLossWeight, bool useConfidenceHead);

        void AccumulateMmtacContextGradients(float[,] dContextA, float[,] dContextB, float[,] contextTypeEmbeddingGrad, float[,] dLiveNewsHidden, float[] dGlobalHidden, int numGlobal, int numStoredNews, int numNews, int numLiveNews, int numPriceContext, int totalContext, int priceOffset);

        void AccumulateGlobalProjectionGradients(float[] dGlobalHidden, float[] globalFeatures, float[,] projectionGrad, float[] biasGrad);

        float[,] ExpandMeanPoolGradient(float[,] pooledGradient, int rowIndex, int rowCount, int embeddingDim);
    }
}
